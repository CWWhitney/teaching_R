# ethnobotanyR News

This version of ethnobotanyR is a patch:

Updated for R 4.0.2:
- Added an ethno_alluvial plot with the ggalluvial extension of ggplot2
- re-installed all the related packages anew (also updated for R 4.0)
'circlize','cowplot','dplyr','ggalluvial','ggplot2','ggridges','reshape', 'magrittr', as well as 'roxygen', 'broom', 'pbapply', and 'rmarkdown'
- Fixed bugs in RIs and RFCs
- Added more information for the Bayes tools