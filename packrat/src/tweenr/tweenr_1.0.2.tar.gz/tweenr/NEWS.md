# tweenr 1.0.2

* Added a `NEWS.md` file to track changes to the package.
* Fixed numerous small bugs
