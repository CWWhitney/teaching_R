library(testthat)
library(datasauRus)

test_check("datasauRus")
