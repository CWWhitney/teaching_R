## datasauRus 0.1.4

* Updated datasets (@jmatejka, #18)

## datasauRus 0.1.2

* First release, contains datasaurus datasets



