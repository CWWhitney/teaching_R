// Import dependencies
extern crate gifski;
